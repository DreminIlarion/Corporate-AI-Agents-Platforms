
  # Corporate AI Agents Platform

  This is a code bundle for Corporate AI Agents Platform. The original project is available at https://www.figma.com/design/pmF5P4qCLWzD83qjFLYTjT/Corporate-AI-Agents-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  